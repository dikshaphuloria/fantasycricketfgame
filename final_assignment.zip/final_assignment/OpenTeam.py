# -*- coding: utf-8 -*-

# Open implementation generated from reading ui file 'OpenTeam.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Open(object):
    def setupUi(self, Open):
        Open.setObjectName("Open")
        Open.resize(311, 209)
        Open.setMinimumSize(QtCore.QSize(311, 209))
        Open.setMaximumSize(QtCore.QSize(311, 209))
        self.label = QtWidgets.QLabel(Open)
        self.label.setGeometry(QtCore.QRect(10, 60, 281, 23))
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(Open)
        self.lineEdit.setGeometry(QtCore.QRect(10, 120, 211, 22))
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.lineEdit.setFont(font)
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton = QtWidgets.QPushButton(Open)
        self.pushButton.setGeometry(QtCore.QRect(230, 120, 75, 23))
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Open)
        QtCore.QMetaObject.connectSlotsByName(Open)

    def retranslateUi(self, Open):
        _translate = QtCore.QCoreApplication.translate
        Open.setWindowTitle(_translate("Open", "Open"))
        self.label.setText(_translate("Open", "Enter Your Teams Name to Proceed:"))
        self.pushButton.setText(_translate("Open", "OK"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Open = QtWidgets.QMainWindow()
    ui = Ui_Open()
    ui.setupUi(Open)
    Open.show()
    sys.exit(app.exec_())
