# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Evaluate.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import sqlite3
Cricket=sqlite3.connect('fantasyCricket.db')


class Ui_Evaluate(object):
    def setupUi(self, Evaluate):
        Evaluate.setObjectName("Evaluate")
        Evaluate.resize(552, 435)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(Evaluate.sizePolicy().hasHeightForWidth())
        Evaluate.setSizePolicy(sizePolicy)
        Evaluate.setMinimumSize(QtCore.QSize(552, 435))
        Evaluate.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu)
        self.verticalLayout = QtWidgets.QVBoxLayout(Evaluate)
        self.verticalLayout.setObjectName("verticalLayout")

        #LABEL
        self.L1 = QtWidgets.QLabel(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.L1.setFont(font)
        self.L1.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.L1.setScaledContents(False)
        self.L1.setAlignment(QtCore.Qt.AlignCenter)
        self.L1.setObjectName("L1")
        self.verticalLayout.addWidget(self.L1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")

        #SELECT TEAM
        self.SelectTeam = QtWidgets.QComboBox(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(8)
        self.SelectTeam.setFont(font)
        self.SelectTeam.setAccessibleName("")
        self.SelectTeam.setAutoFillBackground(False)
        self.SelectTeam.setEditable(False)
        self.SelectTeam.setObjectName("SelectTeam")
        self.SelectTeam.addItem("")

        con=Cricket.execute("SELECT Name FROM Teams")
        data=con.fetchall()
        data=list(set(data))
        for row in data:
            self.SelectTeam.addItem(row[0])
            
        self.horizontalLayout.addWidget(self.SelectTeam)


        spacerItem = QtWidgets.QSpacerItem(20, 20, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)

        #SELECT MATCH
        self.SelectMatch = QtWidgets.QComboBox(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        self.SelectMatch.setFont(font)
        self.SelectMatch.setObjectName("SelectMatch")
        self.SelectMatch.addItem("")
        self.SelectMatch.addItem("")
        self.horizontalLayout.addWidget(self.SelectMatch)
        self.verticalLayout.addLayout(self.horizontalLayout)

        
        self.line = QtWidgets.QFrame(Evaluate)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout.addWidget(self.line)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")

        #PLAYERS LABEL
        self.L2 = QtWidgets.QLabel(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.L2.setFont(font)
        self.L2.setAlignment(QtCore.Qt.AlignCenter)
        self.L2.setObjectName("L2")
        self.horizontalLayout_2.addWidget(self.L2)

        #POINTS LABEL
        self.L3 = QtWidgets.QLabel(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.L3.setFont(font)
        self.L3.setAlignment(QtCore.Qt.AlignCenter)
        self.L3.setObjectName("L3")
        self.horizontalLayout_2.addWidget(self.L3)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")

        #PLAYERS LIST WIDGET
        self.lw1 = QtWidgets.QListWidget(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.lw1.setFont(font)
        self.lw1.setObjectName("lw1")
        self.horizontalLayout_3.addWidget(self.lw1)
        spacerItem1 = QtWidgets.QSpacerItem(60, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(spacerItem1)

        #POINTS LIST WIDGET
        self.lw2 = QtWidgets.QListWidget(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.lw2.setFont(font)
        self.lw2.setObjectName("lw2")
        self.horizontalLayout_3.addWidget(self.lw2)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")

        #CALCULATION BUTTON
        self.b1 = QtWidgets.QPushButton(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.b1.setFont(font)
        self.b1.setObjectName("b1")
        self.b1.clicked.connect(self.calculateScore)
        self.horizontalLayout_4.addWidget(self.b1)


        spacerItem2 = QtWidgets.QSpacerItem(250, 20, QtWidgets.QSizePolicy.MinimumExpanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem2)

        #FINAL SCORE
        self.Score = QtWidgets.QLineEdit(Evaluate)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.Score.setFont(font)
        self.Score.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.Score.setObjectName("Score")
        self.horizontalLayout_4.addWidget(self.Score)
        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.retranslateUi(Evaluate)
        QtCore.QMetaObject.connectSlotsByName(Evaluate)

    def retranslateUi(self, Evaluate):
        _translate = QtCore.QCoreApplication.translate
        Evaluate.setWindowTitle(_translate("Evaluate", "Form"))
        self.L1.setText(_translate("Evaluate", "Evaluate the Performance of your Fantasy Team"))
        self.SelectTeam.setItemText(0, _translate("Evaluate", "SELECT TEAM"))
        self.SelectMatch.setItemText(0, _translate("Evaluate", "SELECT MATCH"))
        self.SelectMatch.setItemText(1, _translate("Evaluate", "Match"))
        
        self.L2.setText(_translate("Evaluate", "Players"))
        self.L3.setText(_translate("Evaluate", "Points"))
        self.b1.setText(_translate("Evaluate", "Calculate Score"))
        self.Score.setText(_translate("Evaluate", "00"))

  

    def calculateScore(self):

        team=self.SelectTeam.currentText()
        self.lw1.clear()
        self.lw2.clear()
        con=Cricket.execute("SELECT * FROM Teams WHERE Name='"+team+"'")
        row=con.fetchone()
        selected=row[1].split(',')
        print(selected)
        self.lw1.addItems(selected)
        count=self.lw1.count()
        total=0
        
        Match=self.SelectMatch.currentText()
        
        for i in range(count-1):
            T1=0
            Batting=0
            Bowling=0
            fielding=0
            
            name=self.lw1.item(i).text()
            con=Cricket.execute("SELECT * FROM "+Match+" WHERE Player='"+name+"'")
            row=con.fetchone()
 
            Batting=int(row[1]/2)
            if Batting>=50:
                Batting+=5
                
            if Batting>=100:
                Batting+=10
                
            if row[1]>0:
                sr=row[1]/row[2]
                
                if sr>=80 and sr<100:
                    Batting+=2
                    
                if sr>=100:
                    Batting+=4

            Batting=Batting+row[3]
            
            Batting=Batting+2*row[4]
            
            Bowling=row[8]*10

            if row[8]==3:
                Bowling=Bowling+5
                
            if row[8]>=5:
                Bowling=Bowling+10
                
            if row[7]>0:
                sc=6*row[7]/row[5]
               
                if sc<=2:
                    Bowling=Bowling+10
                    
                if sc>2 and sc<=3.5:
                    Bowling=Bowling+7
                    
                if sc>3.5 and sc<=4.5:
                    Bowling=Bowling+4
                    
            fielding=(row[9]+row[10]+row[11])*10
            
            T1=Batting+Bowling+fielding
            
            self.lw2.addItem(str(T1))

            print(T1)
            
            total=total+T1


        self.Score.setText(str(total))
\



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Evaluate = QtWidgets.QWidget()
    ui = Ui_Evaluate()
    ui.setupUi(Evaluate)
    Evaluate.show()
    sys.exit(app.exec_())
