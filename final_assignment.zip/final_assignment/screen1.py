# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'screen1.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from NewTeam import Ui_Form 
from OpenTeam import Ui_Open 
from Evaluate import Ui_Evaluate as evaluate
import sqlite3
Cricket=sqlite3.connect('fantasyCricket.db')
curs=Cricket.cursor()



class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(794, 514)
        MainWindow.setMinimumSize(QtCore.QSize(794, 514))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")

        #Batsman
        self.l1 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.l1.setFont(font)
        self.l1.setObjectName("l1")
        self.horizontalLayout.addWidget(self.l1)

        self.bat = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.bat.setFont(font)
        self.bat.setObjectName("bat")
        self.horizontalLayout.addWidget(self.bat)

        #Bowler
        self.l2 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.l2.setFont(font)
        self.l2.setObjectName("l2")
        self.horizontalLayout.addWidget(self.l2)

        self.bwl = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.bwl.setFont(font)
        self.bwl.setObjectName("bwl")
        self.horizontalLayout.addWidget(self.bwl)

        #Allrounder
        self.l3 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.l3.setFont(font)
        self.l3.setObjectName("l3")
        self.horizontalLayout.addWidget(self.l3)

        self.ar = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.ar.setFont(font)
        self.ar.setObjectName("ar")
        self.horizontalLayout.addWidget(self.ar)

        #Wicketkeeper
        self.l4 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.l4.setFont(font)
        self.l4.setObjectName("l4")
        self.horizontalLayout.addWidget(self.l4)

        self.wk = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.wk.setFont(font)
        self.wk.setObjectName("wk")
        self.horizontalLayout.addWidget(self.wk)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")

        #Points Available
        self.l5 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.l5.setFont(font)
        self.l5.setObjectName("l5")
        self.horizontalLayout_2.addWidget(self.l5)

        self.pointsA = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pointsA.setFont(font)
        self.pointsA.setObjectName("pointsA")
        self.horizontalLayout_2.addWidget(self.pointsA)

        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)

        #Points Used
        self.l6 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.l6.setFont(font)
        self.l6.setObjectName("l6")
        self.horizontalLayout_2.addWidget(self.l6)

        self.pointsU = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pointsU.setFont(font)
        self.pointsU.setObjectName("pointsU")
        self.horizontalLayout_2.addWidget(self.pointsU)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)

        #Bat Button
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.rb1 = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.rb1.setFont(font)
        self.rb1.setObjectName("rb1")
        self.horizontalLayout_3.addWidget(self.rb1)
        self.rb1.toggled.connect(self.ctgr)

        #bowler Button
        self.rb2 = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.rb2.setFont(font)
        self.rb2.setObjectName("rb2")
        self.horizontalLayout_3.addWidget(self.rb2)
        self.rb2.toggled.connect(self.ctgr)

        #Allrounder Button
        self.rb3 = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.rb3.setFont(font)
        self.rb3.setObjectName("rb3")
        self.horizontalLayout_3.addWidget(self.rb3)
        self.rb3.toggled.connect(self.ctgr)

        #Wicketkeeper Button
        self.rb4 = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.rb4.setFont(font)
        self.rb4.setObjectName("rb4")
        self.horizontalLayout_3.addWidget(self.rb4)
        self.rb4.toggled.connect(self.ctgr)

        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem1)

        #Team Name
        self.l7 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(12)
        self.l7.setFont(font)
        self.l7.setObjectName("l7")
        self.horizontalLayout_3.addWidget(self.l7)

        self.teamN = QtWidgets.QLineEdit(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        self.teamN.setFont(font)
        self.teamN.setObjectName("teamN")
        self.horizontalLayout_3.addWidget(self.teamN)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")

        #List1
        self.lw1 = QtWidgets.QListWidget(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lw1.sizePolicy().hasHeightForWidth())
        self.lw1.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.lw1.setFont(font)
        self.lw1.setObjectName("lw1")
        self.horizontalLayout_5.addWidget(self.lw1)
        self.lw1.itemDoubleClicked.connect(self.removelist1)
        

        self.label = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Book Antiqua")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.horizontalLayout_5.addWidget(self.label)

        #List2
        self.lw2 = QtWidgets.QListWidget(self.centralwidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lw2.sizePolicy().hasHeightForWidth())
        self.lw2.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.lw2.setFont(font)
        self.lw2.setObjectName("lw2")
        self.horizontalLayout_5.addWidget(self.lw2)
        self.verticalLayout_2.addLayout(self.horizontalLayout_5)
        self.lw2.itemDoubleClicked.connect(self.removelist2)


        #MenuBar
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 794, 22))
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.menubar.setFont(font)
        self.menubar.setObjectName("menubar")
        self.menuManage_Teams = QtWidgets.QMenu(self.menubar)
        font = QtGui.QFont()
        font.setFamily("Century")
        font.setPointSize(10)
        self.menuManage_Teams.setFont(font)
        self.menuManage_Teams.setObjectName("menuManage_Teams")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        #New Team
        self.actionNEW_Team = QtWidgets.QAction(MainWindow)
        self.actionNEW_Team.setObjectName("actionNEW_Team")
        self.actionNEW_Team.setShortcut("Ctrl+N")
        self.actionNEW_Team.triggered.connect(self.newTeam)

        #Open Team
        self.actionOPEN_Team = QtWidgets.QAction(MainWindow)
        self.actionOPEN_Team.setObjectName("actionOPEN_Team")
        self.actionOPEN_Team.setShortcut("Ctrl+O")
        self.actionOPEN_Team.triggered.connect(self.openTeam)
        
        #Save Team
        self.actionSAVE_Team = QtWidgets.QAction(MainWindow)
        self.actionSAVE_Team.setObjectName("actionSAVE_Team")
        self.actionSAVE_Team.setShortcut("Ctrl+S")
        self.actionSAVE_Team.triggered.connect(self.saveTeam)
        
        #Evaluate Team
        self.actionEVALUATE_Team = QtWidgets.QAction(MainWindow)
        self.actionEVALUATE_Team.setObjectName("actionEVALUATE_Team")
        self.actionEVALUATE_Team.setShortcut("Ctrl+E")
        self.actionEVALUATE_Team.triggered.connect(self.evaluateteam)
        
        
        #Quit
        self.actionQuit = QtWidgets.QAction(MainWindow)
        self.actionQuit.setObjectName("actionQuit")
        self.actionQuit.setShortcut("Ctrl+Q")
        self.actionQuit.triggered.connect(self.quit)

        
        self.menuManage_Teams.addAction(self.actionNEW_Team)
        self.menuManage_Teams.addAction(self.actionOPEN_Team)
        self.menuManage_Teams.addSeparator()
        self.menuManage_Teams.addAction(self.actionSAVE_Team)
        self.menuManage_Teams.addSeparator()
        self.menuManage_Teams.addAction(self.actionEVALUATE_Team)
        self.menuManage_Teams.addSeparator()
        self.menuManage_Teams.addAction(self.actionQuit)
        self.menubar.addAction(self.menuManage_Teams.menuAction())

        self.new_screen.pushButton.clicked.connect(self.newTeam)
        self.new_screen.pushButton.clicked.connect(self.Form.close)
        
        self.open_screen.pushButton.clicked.connect(self.openT)
    
        self.t1=0
        self.t2=0
        self.t3=0
        self.t4=0
        self.t5=1000
        self.t6=0
                   
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.l1.setText(_translate("MainWindow", "Batsmen (BAT)"))
        self.bat.setText(_translate("MainWindow", "0"))
        self.l2.setText(_translate("MainWindow", "Bowlers (BWL)"))
        self.bwl.setText(_translate("MainWindow", "0"))
        self.l3.setText(_translate("MainWindow", "Allrounder (AR)"))
        self.ar.setText(_translate("MainWindow", "0"))
        self.l4.setText(_translate("MainWindow", "Wicket-Keeper (WK)"))
        self.wk.setText(_translate("MainWindow", "0"))
        self.l5.setText(_translate("MainWindow", "Points Available:"))
        self.pointsA.setText(_translate("MainWindow", "1000"))
        self.l6.setText(_translate("MainWindow", "Points Used:"))
        self.pointsU.setText(_translate("MainWindow", "0"))
        self.rb1.setText(_translate("MainWindow", "BAT"))
        self.rb2.setText(_translate("MainWindow", "BWL"))
        self.rb3.setText(_translate("MainWindow", "AR"))
        self.rb4.setText(_translate("MainWindow", "WK"))
        self.l7.setText(_translate("MainWindow", "Team Name:"))
        self.label.setText(_translate("MainWindow", ">"))
        self.menuManage_Teams.setTitle(_translate("MainWindow", "Manage Teams"))
        self.actionNEW_Team.setText(_translate("MainWindow", "NEW Team"))
        self.actionNEW_Team.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.actionOPEN_Team.setText(_translate("MainWindow", "OPEN Team"))
        self.actionOPEN_Team.setShortcut(_translate("MainWindow", "Ctrl+O"))
        self.actionSAVE_Team.setText(_translate("MainWindow", "SAVE Team"))
        self.actionSAVE_Team.setShortcut(_translate("MainWindow", "Ctrl+S"))
        self.actionEVALUATE_Team.setText(_translate("MainWindow", "EVALUATE Team"))
        self.actionEVALUATE_Team.setShortcut(_translate("MainWindow", "Ctrl+E"))
        self.actionQuit.setText(_translate("MainWindow", "Quit"))
        self.actionQuit.setShortcut(_translate("MainWindow", "Ctrl+Q"))

    def __init__(self):
        self.Form = QtWidgets.QWidget()
        self.new_screen = Ui_Form()                           
        self.new_screen.setupUi(self.Form)
        
        self.Evaluate= QtWidgets.QWidget()
        self.eval_screen= evaluate()
        self.eval_screen.setupUi(self.Evaluate)

        self.Open = QtWidgets.QMainWindow()
        self.open_screen= Ui_Open()
        self.open_screen.setupUi(self.Open)



    def show(self):
        self.bat.setText(str(self.t1))
        self.bwl.setText(str(self.t2))
        self.ar.setText(str(self.t3))
        self.wk.setText(str(self.t4))
        self.pointsA.setText(str(self.t5))
        self.pointsU.setText(str(self.t6))

    
    def clickMethod(self,title,msg):
        widget=QtWidgets.QMessageBox()
        widget.setText(msg)
        widget.setWindowTitle(title)
        method=widget.exec()


    def newTeam(self):
        self.t1=0
        self.t2=0
        self.t3=0
        self.t4=0
        self.t5=1000
        self.t6=0
        self.lw1.clear()
        self.lw2.clear()
        
        self.Form.show()
        self.name= self.new_screen.lineEdit.text()
        self.teamN.setText(self.name)
        self.show()

    def openTeam(self):
        self.t1=0
        self.t2=0
        self.t3=0
        self.t4=0
        self.t5=1000
        self.t6=0
        self.lw1.clear()
        self.lw2.clear()
        self.show()
        self.Open.show()


    def openT(self):    
        teamname = self.open_screen.lineEdit.text()
        try:
            con=curs.execute("SELECT * from Teams WHERE Name= '"+teamname+"';")
            row=con.fetchone()
            selected=row[1].split(',')
            self.t6=int(row[2])
            self.t5=1000-int(row[2])
            self.lw2.addItems(selected)
            count=self.lw2.count()
            self.teamN.setText(teamname)
            
            for i in range(count-1):
                player=self.lw2.item(i).text()
                curs.execute("SELECT Ctg from stats WHERE Player= '"+player+"';")
                row=curs.fetchone()
                ctg=row[0]
                if ctg=="BAT":
                    self.t1+=1
                if ctg=="BWL":
                    self.t2+=1
                if ctg=="AR":
                    self.t3+=1
                if ctg=="WK":
                    self.t4+=1
                    
            self.Open.close()   
            self.show()
            
        except:
            self.clickMethod("Team Selector","Team name doesn't exist")


    def saveTeam(self):
        count=self.lw2.count()
        name=self.teamN.text()
        select=""
        val=self.t6
        for i in range(count):
            select+=self.lw2.item(i).text()
            if i<count:
                select+=","   
        
        if (self.t1+self.t2+self.t3+self.t4!=11 or self.t5<0):
            self.clickMethod("Team Selector","Insufficient players select 11 players and available points shouldn't be less than 0")
            return
        
        try:
            curs.execute("INSERT INTO Teams (Name,Players,Value) VALUES ('"+name+"','"+select+"','"+str(val)+"');") 
            Cricket.commit()
            self.clickMethod("Team Selector","Team Details Saved Succesfully")
            
        except:
            self.clickMethod("Team Selector","This team name already exist. Try with a new name!!")
            self.teamN.clear()
        



    def evaluateteam(self):
        self.Evaluate.show()



    def quit(self):
        self.clickMethod("Fantasy Cricket","Thank You for visiting!!")
        sys.exit()

    def ctgr(self):
        ctg=''
        if self.rb1.isChecked()==True:
            ctg='BAT'
        if self.rb2.isChecked()==True:
            ctg='BWL'
        if self.rb3.isChecked()==True:
            ctg='AR'
        if self.rb4.isChecked()==True:
            ctg='WK'
        self.addList(ctg)
        


    def criteria(self,ctg,item):
        msg=''
        
        if ctg=="BAT" and self.t1>=4:
            msg="You can't select more than four Batsmen!!"
        if ctg=="BWL" and self.t2>=4:
            msg="You can't select more than four Bowlers!!"
        if ctg=="AR" and self.t3>=2:
            msg="You can't select more than two Allrounders!!"
        if ctg=="WK" and self.t4>=1:
            msg="You can't select more than one wicket-keeper!!"
        if msg!='':
            self.clickMethod('Selection Criteria',msg)
            return False
        
        if self.t5<=0:
            msg="You have used all the points!!"
            self.clickMethod('Selection Criteria',msg)
        
        if ctg=="BAT":
            self.t1+=1
        if ctg=="BWL":
            self.t2+=1
        if ctg=="AR":
            self.t3+=1
        if ctg=="WK":
            self.t4+=1

        curs.execute("SELECT Value FROM stats WHERE Player='"+item.text()+"'")
        row=curs.fetchone()
        self.t5-=int(row[0])
        self.t6+=int(row[0])
        return True
    
    
    def removelist1(self,item):
        
        ctg=''
        if self.rb1.isChecked()==True:
            ctg='BAT'
        if self.rb2.isChecked()==True:
            ctg='BWL'
        if self.rb3.isChecked()==True:
            ctg='AR'
        if self.rb4.isChecked()==True:
            ctg='WK'

        X=self.criteria(ctg,item)

        if X==True:
            self.lw1.takeItem(self.lw1.row(item))

            self.lw2.addItem(item.text())
 
            self.show()



    def removelist2(self,item):
        self.lw2.takeItem(self.lw2.row(item))
        
        con= curs.execute("SELECT Player,Value,Ctg from stats where Player='"+item.text()+"'")
        row=con.fetchone()
        self.t5=self.t5+int(row[1])
        self.t6=self.t6-int(row[1])
        ctg=row[2]
        if ctg=="BAT":
            self.t1-=1
            if self.rb1.isChecked()==True:
                self.lw1.addItem(item.text())

        if ctg=="BWL":
            self.t2-=1
            if self.rb2.isChecked()==True:
                self.lw1.addItem(item.text())

        if ctg=="AR":
            self.t3-=1
            if self.rb3.isChecked()==True:
                self.lw1.addItem(item.text())

        if ctg=="WK":
            self.t4-=1
            if self.rb4.isChecked()==True:
                self.lw1.addItem(item.text())
                
        self.show()


    def addList(self,ctg):

        if self.teamN.text()=='':
            self.clickMethod("List","Enter name of team")
            return
 
        self.lw1.clear()
        con= curs.execute("SELECT Player from stats where Ctg='"+ctg+"';")

        for row in con:
            selected=[]
            for i in range(self.lw2.count()):
                selected.append(self.lw2.item(i).text())
            if row[0] not in selected:
                self.lw1.addItem(row[0])
        




            
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
