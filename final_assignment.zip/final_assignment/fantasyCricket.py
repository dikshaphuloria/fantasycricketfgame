import sqlite3

Cricket=sqlite3.connect('fantasyCricket.db')
curs=Cricket.cursor()
curs.execute('''CREATE TABLE Match(
Player Text (20) NOT NULL,
Scored INTEGER,
Faced INTEGER,
Fours INTEGER,
Sixes INTEGER,
Bowled INTEGER,
Maiden INTEGER,
Given INTEGER,
Wkts INTEGER,
Catches INTEGER,
Stumping INTEGER,
RO INTEGER);''')

Cricket.close()


